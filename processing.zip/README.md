# BAM
 Building ANUGA Models

 Scripts for building and running ANUGA hydrodynamic model base on open-source software and publicly available data

 <br></br>

 Author: Alexandra Christensen
 Affiliation: Jet Propulsion Laboratory, California Institute of Technology
 Acknowledgement: The research was carried out at the Jet Propulsion Laboratory, California Institute of Technology, under a contract with the National Aeronautics and Space Administration (80NM0018D0004)
 <br></br>

 © 2022 California Institute of Technology. Government sponsorship acknowledged
